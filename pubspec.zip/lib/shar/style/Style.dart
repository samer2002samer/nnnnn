import 'package:flutter/material.dart';


class App_Style{

  static  ThemeData light_theme= ThemeData(
      scaffoldBackgroundColor: Colors.red

  );





}